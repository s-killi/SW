package de.othr.jwtclientdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JwtClientDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}

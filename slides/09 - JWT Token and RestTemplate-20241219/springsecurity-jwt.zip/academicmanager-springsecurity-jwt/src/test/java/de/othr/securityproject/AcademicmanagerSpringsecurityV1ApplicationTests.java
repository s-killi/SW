package de.othr.securityproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AcademicmanagerSpringsecurityV1ApplicationTests {

	@Test
	void contextLoads() {
	}

}

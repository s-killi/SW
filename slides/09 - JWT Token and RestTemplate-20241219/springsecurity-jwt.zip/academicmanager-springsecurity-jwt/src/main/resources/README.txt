This is the basic application with Spring Security Login.
No other feature is added to this project.
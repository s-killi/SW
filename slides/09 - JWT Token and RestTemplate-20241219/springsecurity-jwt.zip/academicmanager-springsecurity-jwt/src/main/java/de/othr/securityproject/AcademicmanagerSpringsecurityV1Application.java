package de.othr.securityproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AcademicmanagerSpringsecurityV1Application {

	public static void main(String[] args) {
		SpringApplication.run(AcademicmanagerSpringsecurityV1Application.class, args);
	}

}

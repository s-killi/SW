package de.othr.securityproject.repository;

import de.othr.securityproject.model.Registration;

public interface RegistrationRepositoryI extends MyBaseRepository<Registration, Long>{

}

package de.othr.securityproject;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
 


//@ImportResource("classpath:beans.xml")
@SpringBootApplication
public class RESTProjecttApplication {
	

	
	public static void main(String[] args) {
		SpringApplication.run(RESTProjecttApplication.class, args);
	}

}

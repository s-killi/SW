package oth.ics.wtp.todo.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import oth.ics.wtp.todo.dtos.TodoListBriefDto;
import oth.ics.wtp.todo.dtos.TodoListCreateDto;
import oth.ics.wtp.todo.dtos.TodoListDto;
import oth.ics.wtp.todo.dtos.TodoListUpdateDto;
import oth.ics.wtp.todo.services.TodoListService;

import java.util.List;

@RestController public class TodoListController {
    private final TodoListService service;
    @Autowired public TodoListController(TodoListService service) {
        this.service = service;
    }

    @GetMapping (path="lists")
    public List<TodoListBriefDto> listTodoLists() {
        return service.list();
    }

    @PostMapping(path="lists")
    @ResponseStatus(HttpStatus.CREATED)
    public TodoListDto createTodoList(@RequestBody TodoListCreateDto createDto) {
        return service.create(createDto);
    }

    @GetMapping(path="lists/{id}")
    public TodoListDto getTodoList(@PathVariable("id") long id) {
        return service.get(id);
    }

    @PutMapping(path="lists/{id}")
    public TodoListDto updateTodoList(@PathVariable("id") long id, @RequestBody TodoListUpdateDto updateDto) {
        return service.update(id, updateDto);
    }

    @DeleteMapping(path = "lists/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void deleteTodoList(@PathVariable("id") long id) {
        service.delete(id);
    }
}

package oth.ics.wtp.todo.entities;

public enum Status {
    PENDING,
    DONE
}

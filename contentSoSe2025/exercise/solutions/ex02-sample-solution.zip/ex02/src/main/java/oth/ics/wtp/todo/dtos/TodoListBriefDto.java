package oth.ics.wtp.todo.dtos;

public record TodoListBriefDto(long id, String name) { }

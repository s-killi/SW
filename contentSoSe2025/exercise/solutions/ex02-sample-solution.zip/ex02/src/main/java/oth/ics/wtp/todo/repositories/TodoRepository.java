package oth.ics.wtp.todo.repositories;

import org.springframework.data.repository.CrudRepository;
import oth.ics.wtp.todo.entities.Todo;

import java.util.Optional;

public interface TodoRepository extends CrudRepository<Todo, Long> {
    boolean existsByListIdAndTask(long listId, String task);
    Optional<Todo> findByListIdAndId(long listId, long id);
}

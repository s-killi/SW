package oth.ics.wtp.todo.entities;

import jakarta.persistence.*;

import java.util.List;

import static jakarta.persistence.CascadeType.REMOVE;
import static jakarta.persistence.FetchType.EAGER;

@Entity public class TodoList {
    @Id @GeneratedValue private long id;
    private String name;
    @OneToMany(mappedBy="list", fetch=EAGER, cascade=REMOVE) List<Todo> todos;

    public TodoList() { }

    public TodoList(String name) {
        this.name = name;
    }

    public long getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public List<Todo> getTodos() {
        return todos;
    }

    public void setName(String name) {
        this.name = name;
    }
}

package oth.ics.wtp.todo.controllers;

import jakarta.websocket.server.PathParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import oth.ics.wtp.todo.dtos.TodoCreateDto;
import oth.ics.wtp.todo.dtos.TodoDto;
import oth.ics.wtp.todo.dtos.TodoUpdateDto;
import oth.ics.wtp.todo.services.TodoService;

import java.util.List;

@RestController public class TodoController {
    private final TodoService service;
    @Autowired public TodoController(TodoService service) {
        this.service = service;
    }

    @PostMapping(path = "lists/{listId}/todos")
    @ResponseStatus(HttpStatus.CREATED)
    public TodoDto createTodo(@PathVariable("listId") long listId, @RequestBody TodoCreateDto createDto) {
        return service.create(listId, createDto);
    }

    @GetMapping(path="lists/{listId}/todos/{id}")
    public TodoDto getTodo(@PathVariable("listId") long listId, @PathVariable("id") long id) {
        return service.get(listId, id);
    }

    @PutMapping(path="lists/{listId}/todos/{id}")
    public TodoDto updateTodo(@PathVariable("listId") long listId, @PathVariable("id") long id,
                                    @RequestBody TodoUpdateDto updateDto) {
        return service.update(listId, id, updateDto);
    }

    @DeleteMapping(path="lists/{listId}/todos/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void deleteTodo(@PathVariable("listId") long listId, @PathVariable("id") long id) {
        service.delete(listId, id);
    }
}

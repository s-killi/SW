package oth.ics.wtp.todo.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;
import oth.ics.wtp.todo.dtos.TodoListBriefDto;
import oth.ics.wtp.todo.dtos.TodoListCreateDto;
import oth.ics.wtp.todo.dtos.TodoListDto;
import oth.ics.wtp.todo.dtos.TodoListUpdateDto;
import oth.ics.wtp.todo.entities.TodoList;
import oth.ics.wtp.todo.repositories.TodoListRepository;

import java.util.List;
import java.util.stream.StreamSupport;

@Service
public class TodoListService {
    private final TodoListRepository repo;
    @Autowired public TodoListService(TodoListRepository repo) {
        this.repo = repo;
    }

    public List<TodoListBriefDto> list() {
        return StreamSupport.stream(repo.findAll().spliterator(), false)
                .map(TodoListService::toBriefDto).toList();
    }

    public TodoListDto create(TodoListCreateDto createDto) {
        if (repo.existsByName(createDto.name())) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "list with same name already exists");
        }
        TodoList list = toEntity(createDto);
        return toDto(repo.save(list));
    }

    public TodoListDto get(long id) {
        return repo.findById(id).map(TodoListService::toDto)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND));
    }

    public TodoListDto update(long id, TodoListUpdateDto updateDto) {
        TodoList list = repo.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND));
        list.setName(updateDto.name());
        return toDto(repo.save(list));
    }

    public void delete(long id) {
        if (!repo.existsById(id)) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND);
        }
        repo.deleteById(id);
    }

    static TodoListDto toDto(TodoList list) {
        return new TodoListDto(list.getId(), list.getName(),
                list.getTodos() == null ? null : list.getTodos().stream().map(TodoService::toDto).toList());
    }

    static TodoListBriefDto toBriefDto(TodoList list) {
        return new TodoListBriefDto(list.getId(), list.getName());
    }

    static TodoList toEntity(TodoListCreateDto create) {
        return new TodoList(create.name());
    }
}

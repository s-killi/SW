package oth.ics.wtp.todo.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;
import oth.ics.wtp.todo.dtos.StatusDto;
import oth.ics.wtp.todo.dtos.TodoCreateDto;
import oth.ics.wtp.todo.dtos.TodoDto;
import oth.ics.wtp.todo.dtos.TodoUpdateDto;
import oth.ics.wtp.todo.entities.Status;
import oth.ics.wtp.todo.entities.Todo;
import oth.ics.wtp.todo.entities.TodoList;
import oth.ics.wtp.todo.repositories.TodoListRepository;
import oth.ics.wtp.todo.repositories.TodoRepository;

import java.time.Instant;

@Service public class TodoService {
    private final TodoListRepository listRepo;
    private final TodoRepository repo;

    @Autowired public TodoService(TodoListRepository listRepo, TodoRepository repo) {
        this.listRepo = listRepo;
        this.repo = repo;
    }

    public TodoDto create(long listId, TodoCreateDto createDto) {
        TodoList list = ensureListExists(listId);
        if (repo.existsByListIdAndTask(listId, createDto.task())) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "task already exists in list");
        }
        Todo todo = toEntity(createDto);
        todo.setList(list);
        repo.save(todo);
        listRepo.save(list);
        return toDto(todo);
    }

    public TodoDto get(long listId, long id) {
        return toDto(ensureTodoExists(listId, id));
    }

    public TodoDto update(long listId, long id, TodoUpdateDto updateDto) {
        Todo todo = ensureTodoExists(listId, id);
        todo.setTask(updateDto.task());
        todo.setStatus(Status.valueOf(updateDto.status().name()));
        return toDto(repo.save(todo));
    }

    public void delete(long listId, long id) {
        repo.delete(ensureTodoExists(listId, id));
    }

    private TodoList ensureListExists(long listId) {
        return listRepo.findById(listId).orElseThrow(() ->
                new ResponseStatusException(HttpStatus.NOT_FOUND));
    }

    private Todo ensureTodoExists(long listId, long id) {
        return repo.findByListIdAndId(listId, id).orElseThrow(() ->
            new ResponseStatusException(HttpStatus.NOT_FOUND));
    }

    static TodoDto toDto(Todo todo) {
        return new TodoDto(todo.getId(), todo.getTask(), todo.getCreatedAt(),
                StatusDto.valueOf(todo.getStatus().name()));
    }

    static Todo toEntity(TodoCreateDto createDto) {
        return new Todo(Instant.now(), createDto.task(), Status.PENDING);
    }
}

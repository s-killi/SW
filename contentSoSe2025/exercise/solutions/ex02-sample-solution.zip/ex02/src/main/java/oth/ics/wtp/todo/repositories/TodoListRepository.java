package oth.ics.wtp.todo.repositories;

import org.springframework.data.repository.CrudRepository;
import oth.ics.wtp.todo.entities.TodoList;

public interface TodoListRepository extends CrudRepository<TodoList, Long> {
    boolean existsByName(String name);
}

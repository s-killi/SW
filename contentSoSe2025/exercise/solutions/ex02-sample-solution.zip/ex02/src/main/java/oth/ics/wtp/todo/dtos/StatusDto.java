package oth.ics.wtp.todo.dtos;

public enum StatusDto {
    PENDING,
    DONE
}

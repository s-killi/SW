package oth.ics.wtp.todo.dtos;

public record TodoCreateDto(String task) { }

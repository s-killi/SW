package oth.ics.wtp.todo.dtos;

public record TodoListUpdateDto(String name) { }

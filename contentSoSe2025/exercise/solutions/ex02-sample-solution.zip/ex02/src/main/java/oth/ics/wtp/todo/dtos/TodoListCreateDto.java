package oth.ics.wtp.todo.dtos;

public record TodoListCreateDto(String name) { }

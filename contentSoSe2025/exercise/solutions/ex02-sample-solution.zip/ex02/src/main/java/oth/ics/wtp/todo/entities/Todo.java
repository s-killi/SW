package oth.ics.wtp.todo.entities;

import jakarta.persistence.*;
import org.hibernate.annotations.OnDelete;

import java.time.Instant;

import static org.hibernate.annotations.OnDeleteAction.CASCADE;

@Entity public class Todo {
    @Id @GeneratedValue private long id;
    private Instant createdAt;
    private String task;
    private Status status;
    @ManyToOne @OnDelete(action=CASCADE) private TodoList list;

    public Todo() { }

    public Todo(Instant createdAt, String task, Status status) {
        this.createdAt = createdAt;
        this.task = task;
        this.status = status;
    }

    public long getId() {
        return id;
    }

    public Instant getCreatedAt() {
        return createdAt;
    }

    public String getTask() {
        return task;
    }

    public Status getStatus() {
        return status;
    }

    public void setList(TodoList list) {
        this.list = list;
    }

    public void setTask(String task) {
        this.task = task;
    }

    public void setStatus(Status status) {
        this.status = status;
    }
}

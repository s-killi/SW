package oth.ics.wtp.todo.dtos;

import java.time.Instant;

public record TodoDto(long id, String task, Instant createdAt, StatusDto status) { }

package oth.ics.wtp.todo.dtos;

public record TodoUpdateDto(String task, StatusDto status) { }
